export class Mahasiswa{
    id : number;
    nama : string;
    email : string;
    jurusan : string;
    fakultas : string;
}